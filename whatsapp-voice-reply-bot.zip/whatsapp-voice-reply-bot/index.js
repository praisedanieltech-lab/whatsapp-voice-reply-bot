const { Client, LocalAuth, MessageMedia } = require("whatsapp-web.js");
const qrcode = require("qrcode-terminal");
const express = require("express");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");
const { promisify } = require("util");
const googleTTS = require("google-tts-api");
const ffmpegPath = require("@ffmpeg-installer/ffmpeg").path;

const execFileAsync = promisify(execFile);
const app = express();
const PORT = process.env.PORT || 8080;

const AUDIO_DIR = path.join(__dirname, "audio");
fs.mkdirSync(AUDIO_DIR, { recursive: true });

let botStatus = "Starting";

app.get("/", (req, res) => {
  res.json({
    bot: "WhatsApp Voice Reply Bot",
    status: botStatus
  });
});

app.get("/health", (req, res) => {
  res.json({ status: "ok", bot: botStatus });
});

app.listen(PORT, () => {
  console.log(`Web server running on port ${PORT}`);
});

const client = new Client({
  authStrategy: new LocalAuth({
    clientId: "voice-reply-bot"
  }),
  puppeteer: {
    headless: true,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--no-first-run",
      "--no-zygote",
      "--disable-gpu"
    ]
  }
});

client.on("qr", (qr) => {
  botStatus = "Waiting for QR scan";
  console.log("\nSCAN THIS QR CODE WITH WHATSAPP\n");
  qrcode.generate(qr, { small: true });
});

client.on("authenticated", () => {
  botStatus = "Authenticated";
  console.log("WhatsApp authenticated.");
});

client.on("ready", () => {
  botStatus = "Online";
  console.log("WhatsApp Voice Reply Bot is ONLINE.");
});

client.on("auth_failure", (message) => {
  botStatus = "Authentication failed";
  console.error("Authentication failure:", message);
});

client.on("disconnected", (reason) => {
  botStatus = "Disconnected";
  console.log("WhatsApp disconnected:", reason);
});

function makeReply(text) {
  const message = text.toLowerCase().trim();

  if (/^(hi|hello|hey|good morning|good afternoon|good evening)\b/.test(message)) {
    return "Hello! Thanks for reaching out. How can I help you today?";
  }

  if (message.includes("price") || message.includes("cost") || message.includes("how much")) {
    return "Thanks for asking. Please tell me which service you are interested in, and I will give you the details and price.";
  }

  if (message.includes("service") || message.includes("what do you do")) {
    return "I can help with information about our services, pricing, and general questions. Tell me what you need and I will guide you.";
  }

  if (message.includes("thank")) {
    return "You're welcome. I'm happy to help. If you have another question, just send me a message.";
  }

  return "Thanks for your message. I received it. Please give me a little more detail about what you need, and I will help you.";
}

async function downloadTTS(text, mp3Path) {
  const url = googleTTS.getAudioUrl(text, {
    lang: "en",
    slow: false,
    host: "https://translate.google.com"
  });

  const response = await axios.get(url, { responseType: "arraybuffer" });
  fs.writeFileSync(mp3Path, Buffer.from(response.data));
}

async function convertToWhatsAppVoice(mp3Path, oggPath) {
  await execFileAsync(ffmpegPath, [
    "-y",
    "-i", mp3Path,
    "-c:a", "libopus",
    "-b:a", "32k",
    "-vbr", "on",
    "-application", "voip",
    "-ac", "1",
    "-ar", "48000",
    oggPath
  ]);
}

async function createVoiceNote(text) {
  const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const mp3Path = path.join(AUDIO_DIR, `${id}.mp3`);
  const oggPath = path.join(AUDIO_DIR, `${id}.ogg`);

  await downloadTTS(text, mp3Path);
  await convertToWhatsAppVoice(mp3Path, oggPath);

  try {
    fs.unlinkSync(mp3Path);
  } catch (_) {}

  return oggPath;
}

async function cleanup(file) {
  try {
    if (fs.existsSync(file)) fs.unlinkSync(file);
  } catch (_) {}
}

client.on("message", async (message) => {
  try {
    if (message.fromMe) return;
    if (message.from === "status@broadcast") return;

    const text = (message.body || "").trim();
    if (!text) return;

    console.log(`Message from ${message.from}: ${text}`);

    const reply = makeReply(text);
    const voicePath = await createVoiceNote(reply);

    const media = MessageMedia.fromFilePath(voicePath);

    await client.sendMessage(message.from, media, {
      sendAudioAsVoice: true
    });

    console.log(`Voice reply sent to ${message.from}`);
    await cleanup(voicePath);
  } catch (error) {
    console.error("Message handling error:", error);
  }
});

client.initialize();
