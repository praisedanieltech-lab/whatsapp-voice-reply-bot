# WhatsApp Voice Reply Bot

A simple WhatsApp bot that receives a text message and replies with a WhatsApp voice note.

## How it works

1. WhatsApp sends a message to the bot.
2. The bot creates a short reply.
3. Google TTS converts the reply to speech.
4. FFmpeg converts the audio to Opus/Ogg.
5. WhatsApp sends it as a voice note.

## Run locally

```bash
npm install
npm start
```

Scan the QR code shown in the terminal with the WhatsApp account you want to use.

## Railway

Create a GitHub repository, upload these files, then deploy the repository on Railway.

Set the service start command to:

```bash
npm start
```

The server listens on:

```text
PORT
```

Railway supplies this automatically.

## Important session note

The WhatsApp login session is stored in `.wwebjs_auth`. A normal ephemeral deployment can lose this session after a new deployment/rebuild. For a production setup, use persistent storage or switch to the official WhatsApp Cloud API.

## Changing the replies

Edit the `makeReply()` function in `index.js`.

The current version is rule-based so it does not need an AI API key.

## Testing

Send the WhatsApp account a message such as:

- Hello
- What services do you offer?
- How much does it cost?

The bot should answer with a voice note.
